package com.example.gym;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    public Button yourPlan;
    public Button allActivities;
    public Button aboutUs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Initializer();

        setOnClickListeners();
    }
    public void Initializer(){
        yourPlan = findViewById(R.id.seePlanBtn);
        allActivities = findViewById(R.id.seeAllActivities);
        aboutUs = findViewById(R.id.aboutUs);
    }

    public void setOnClickListeners(){
        yourPlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        allActivities.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SeeAllActivitiesActivitiy.class);
                startActivity(intent);
            }
        });

        aboutUs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }
}