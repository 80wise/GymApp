package com.example.gym;

public class Exercise {
    private String name;
    private String pictureUrl;
    private String description;
    private boolean done;

    public Exercise(String name, String pictureUrl, String description) {
        this.name = name;
        this.pictureUrl = pictureUrl;
        this.description = description;
        done = false;
    }

    public Exercise() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPictureUrl() {
        return pictureUrl;
    }

    public void setPictureUrl(String pictureUrl) {
        this.pictureUrl = pictureUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isDone() {
        return done;
    }

    public void setDone(boolean done) {
        this.done = done;
    }
}
