package com.example.gym;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.ArrayList;

public class SeeAllActivitiesActivitiy extends AppCompatActivity {

    private static final String TAG = "SeeAllActivitiesActivit";
    private RecyclerView exerciseRecView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_all_activities_activitiy);

        Log.d(TAG, "onCreate: started");

        exerciseRecView = (RecyclerView) findViewById(R.id.exerciseRecView);

        // the is a context in the constructor just in case it doesn't work
        ExercisesRecViewAdapter adapter = new ExercisesRecViewAdapter();
        exerciseRecView.setAdapter(adapter);
        exerciseRecView.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<Exercise> exercises = new ArrayList<>();
        //add exercises
        exercises.add(new Exercise("Push up",
                "https://pixabay.com/fr/photos/burpee-faire-monter-planche-1203906/",
                "lorem ipsum"));
        exercises.add(new Exercise("Squat",
                "https://pixabay.com/fr/photos/supprimer-perte-de-poids-maigrir-4559344/",
                "lorem ipsum"));
        exercises.add(new Exercise("Chest fly",
                "https://www.istockphoto.com/fr/photo/homme-fait-mouche-debout-c%C3%A2ble-sur-tour-gm1022762870-274555531?phrase=chest%20fly%20exercise",
                "lorem ipsum"));
        exercises.add(new Exercise("leg press",
                "https://pixabay.com/fr/photos/homme-femme-entra%c3%aenement-5886578/",
                "lorem ipsum"));

        adapter.setExercises(exercises);
    }
}